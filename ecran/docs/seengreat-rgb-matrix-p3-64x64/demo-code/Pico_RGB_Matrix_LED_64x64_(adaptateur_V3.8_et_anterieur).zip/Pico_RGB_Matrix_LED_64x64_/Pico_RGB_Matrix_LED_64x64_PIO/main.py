import board
import displayio
import framebufferio
import rgbmatrix
import time
from math import sin
import adafruit_display_text.label
import terminalio
from adafruit_bitmap_font import bitmap_font

# Display configuration
bit_depth_value = 4
unit_width = 64
unit_height = 64
chain_width = 1
chain_height = 1
serpentine_value = True

width_value = unit_width * chain_width
height_value = unit_height * chain_height

# Release previous displays
displayio.release_displays()

# Initialize RGB matrix - Using CircuitPython's rgbmatrix library which internally uses PIO
# Note: CircuitPython's rgbmatrix library is optimized for Raspberry Pi Pico and automatically uses PIO
matrix = rgbmatrix.RGBMatrix(
    width=width_value, height=height_value, bit_depth=bit_depth_value,
    rgb_pins=[board.GP2, board.GP3, board.GP4, board.GP5, board.GP8, board.GP9],
    addr_pins=[board.GP10, board.GP16, board.GP18, board.GP20, board.GP22],  # Including E pin for 1/32 scan
    clock_pin=board.GP11, latch_pin=board.GP12, output_enable_pin=board.GP13,
    tile=chain_height, serpentine=serpentine_value,
    doublebuffer=True  # Enable double buffering for better performance
)

# Create display object
DISPLAY = framebufferio.FramebufferDisplay(matrix, auto_refresh=True, rotation=180)

# Global variables
now = t0 = time.monotonic_ns()
append_flag = 0

class RGB_Api():
    def __init__(self):
        # Set image
        self.image = 'wales_128x64.bmp'
        
        # Set text
        self.txt_str = "Raspberry"
        self.txt_color = 0x0000ff
        self.txt_x = 0
        self.txt_y = 32
        self.txt_font = terminalio.FONT
        self.txt_line_spacing = 0.8
        self.txt_scale = 1
        
        # Set scroll speed
        self.scroll_speed = 30
        
        # The following code doesn't need to be set
        self.sroll_BITMAP = displayio.OnDiskBitmap(open(self.image, 'rb'))
        self.sroll_image1 = displayio.TileGrid(
                self.sroll_BITMAP,
                pixel_shader=getattr(self.sroll_BITMAP, 'pixel_shader', displayio.ColorConverter()),
                width=1,
                height=1,
                x=0,
                y=0,
                tile_width=self.sroll_BITMAP.width,
                tile_height=self.sroll_BITMAP.height)
        self.sroll_image2 = displayio.TileGrid(
                self.sroll_BITMAP,
                pixel_shader=getattr(self.sroll_BITMAP, 'pixel_shader', displayio.ColorConverter()),
                width=1,
                height=1,
                x=-self.sroll_BITMAP.width,
                y=-self.sroll_BITMAP.height,
                tile_width=self.sroll_BITMAP.width,
                tile_height=self.sroll_BITMAP.height)
        if self.txt_font == terminalio.FONT:
            self.txt_font = terminalio.FONT
        else:
            self.txt_font = bitmap_font.load_font(self.txt_font)
        self.sroll_text1 = adafruit_display_text.label.Label(
                self.txt_font,
                color=self.txt_color,
                line_spacing=self.txt_line_spacing,
                scale=self.txt_scale,
                text=self.txt_str)
        self.sroll_text1.x = 0
        self.sroll_text1.y = DISPLAY.height // 2
        self.sroll_text2 = adafruit_display_text.label.Label(
                self.txt_font,
                color=self.txt_color,
                line_spacing=self.txt_line_spacing,
                scale=self.txt_scale,
                text=self.txt_str)
        self.sroll_text2.x = -self.sroll_text1.bounding_box[2]
        self.sroll_text2.y = DISPLAY.height // 2
        
        self.rebound_flag = 0  # Rebound flag
        self.sroll_object = 0
    
    # @brief: Display an image in static mode
    # @param: self
    # @retval: None
    def static_image(self):
        # Ensure previous display resources are released
        global GROUP
        if hasattr(GROUP, 'pop'):
            while len(GROUP) > 0:
                GROUP.pop()
        
        # Load image
        try:
            BITMAP = displayio.OnDiskBitmap(open(self.image, 'rb'))
            print(f"Successfully loaded image: {self.image}, size: {BITMAP.width}x{BITMAP.height}")
        except Exception as e:
            print(f"Failed to load image: {e}")
            # Create a red test image as fallback
            BITMAP = displayio.Bitmap(64, 64, 2)
            BITMAP.fill(1)
            print("Using red test image")
        
        # Create new display group
        GROUP = displayio.Group()
        GROUP.append(displayio.TileGrid(
            BITMAP,
            pixel_shader=getattr(BITMAP, 'pixel_shader', displayio.ColorConverter()),
            width=1,
            height=1,
            tile_width=BITMAP.width,
            tile_height=BITMAP.height
        ))

        DISPLAY.root_group = GROUP
        DISPLAY.refresh()
        print("Image display completed")
        
    # @brief: Display image horizontally from left to right
    # @param: self
    # @retval: None
    def image_left_to_right_horizontal(self):
        global append_flag
        self.sroll_image2.y = 0
        x = self.sroll_image1.x + 1
        time.sleep(1/self.scroll_speed)
        if x > self.sroll_BITMAP.width:
            x = 0
        self.sroll_image1.x = x
        self.sroll_image2.x = -(self.sroll_BITMAP.width - self.sroll_image1.x)
        if append_flag == 0:
            append_flag = 1
            GROUP.append(RGB.sroll_image1)
            GROUP.append(RGB.sroll_image2)
            DISPLAY.root_group = GROUP

    # @brief: Display image horizontally from right to left
    # @param: self
    # @retval: None
    def image_right_to_left_horizontal(self):
        global append_flag
        self.sroll_image2.y = 0
        x = self.sroll_image1.x - 1
        time.sleep(1/self.scroll_speed)
        if x < 0:
            x = self.sroll_BITMAP.width
        self.sroll_image1.x = x
        self.sroll_image2.x = -(self.sroll_BITMAP.width - self.sroll_image1.x)
        if append_flag == 0:
            append_flag = 1
            GROUP.append(RGB.sroll_image1)
            GROUP.append(RGB.sroll_image2)
            DISPLAY.root_group = GROUP
        
    # @brief: Display image vertically from top to bottom
    # @param: self
    # @retval: None
    def image_up_to_down_vertical(self):
        global append_flag
        self.sroll_image2.x = 0
        y = self.sroll_image1.y + 1
        time.sleep(1/self.scroll_speed)
        if y > self.sroll_BITMAP.height:
            y = 0
        self.sroll_image1.y = y
        self.sroll_image2.y = -(self.sroll_BITMAP.height - self.sroll_image1.y)
        if append_flag == 0:
            append_flag = 1
            GROUP.append(RGB.sroll_image1)
            GROUP.append(RGB.sroll_image2)
            DISPLAY.root_group = GROUP
        
    # @brief: Display image vertically from bottom to top
    # @param: self
    # @retval: None
    def image_down_to_up_vertical(self):
        global append_flag
        self.sroll_image2.x = 0
        y = self.sroll_image1.y - 1
        time.sleep(1/self.scroll_speed)
        if y < 0:
            y = self.sroll_BITMAP.height
        self.sroll_image1.y = y
        self.sroll_image2.y = -(self.sroll_BITMAP.height - self.sroll_image1.y)
        if append_flag == 0:
            append_flag = 1
            GROUP.append(RGB.sroll_image1)
            GROUP.append(RGB.sroll_image2)
            DISPLAY.root_group = GROUP
    
    # @brief: Display text in static mode
    # @param: self
    # @retval: None
    def static_text(self):
        TEXT = adafruit_display_text.label.Label(
            self.txt_font,
            color=self.txt_color,
            scale=self.txt_scale,
            text=self.txt_str,
            line_spacing=self.txt_line_spacing
            )
        TEXT.x = self.txt_x
        TEXT.y = self.txt_y
        GROUP = displayio.Group()
        GROUP.append(TEXT)
        DISPLAY.root_group = GROUP
        DISPLAY.refresh()
        while True:
            pass
        
    
    # @brief: Display text in sinusoidal scroll from left to right
    # @param: self
    # @retval: None
    def text_sin_left_to_right(self):
        global append_flag
        global now
        global t0  
        T = 1/self.scroll_speed
        t_max = t0 + T
        n = 5/self.scroll_speed
        A = 7.5
        Y0 = DISPLAY.height // 2
        dt = (now - t0) * 1e-9
        time.sleep(1/self.scroll_speed)
        x = self.sroll_text1.x + 1
        if x > DISPLAY.width:
            x = 0
        self.sroll_text1.x = x
        self.sroll_text2.x = -(DISPLAY.width - self.sroll_text1.x)
        y = round(Y0 + sin(dt / n) * A)
        self.sroll_text2.y = self.sroll_text1.y = y
        while True:
            now = time.monotonic_ns()
            if now > t_max:
                break
            time.sleep((t_max - now) * 1e-9)
        t_max += T
        if append_flag == 0:
            append_flag = 1
            GROUP.append(self.sroll_text1)
            GROUP.append(self.sroll_text2)
            DISPLAY.root_group = GROUP
        
    # @brief: Display text in sinusoidal scroll from right to left
    # @param: self
    # @retval: None
    def text_sin_right_to_left(self):
        global append_flag
        global now
        global t0  
        T = 1/self.scroll_speed
        t_max = t0 + T
        n = 5/self.scroll_speed
        A = 7.5
        Y0 = DISPLAY.height // 2
        dt = (now - t0) * 1e-9
        time.sleep(1/self.scroll_speed)
        x = self.sroll_text1.x - 1
        if x < 0:
            x = DISPLAY.width
        self.sroll_text1.x = x
        self.sroll_text2.x = -(DISPLAY.width - self.sroll_text1.x)
        y = round(Y0 + sin(dt / n) * A)
        self.sroll_text2.y = self.sroll_text1.y = y
        while True:
            now = time.monotonic_ns()
            if now > t_max:
                break
            time.sleep((t_max - now) * 1e-9)
        t_max += T
        if append_flag == 0:
            append_flag = 1
            GROUP.append(self.sroll_text1)
            GROUP.append(self.sroll_text2)
            DISPLAY.root_group = GROUP
    
    # @brief: Display text in sinusoidal scroll from top to bottom
    # @param: self
    # @retval: None
    def text_sin_up_to_down(self):
        global append_flag
        global now
        global t0
        T = 1/self.scroll_speed
        t_max = t0 + T
        n = 5/self.scroll_speed
        A = 5
        X0 = 6
        dt = (now - t0) * 1e-9
        time.sleep(1/self.scroll_speed)
        y = self.sroll_text1.y + 1
        if y > DISPLAY.height:
            y = 0
        self.sroll_text1.y = y
        self.sroll_text2.y = -(DISPLAY.height - self.sroll_text1.y)
        x = round(X0 + sin(dt / n) * A)
        self.sroll_text2.x = self.sroll_text1.x = x
        while True:
            now = time.monotonic_ns()
            if now > t_max:
                break
            time.sleep((t_max - now) * 1e-9)
        t_max += T
        if append_flag == 0:
            append_flag = 1
            GROUP.append(self.sroll_text1)
            GROUP.append(self.sroll_text2)
            DISPLAY.root_group = GROUP

    # @brief: Display text in sinusoidal scroll from bottom to top
    # @param: self
    # @retval: None
    def text_sin_down_to_up(self):
        global append_flag
        global now
        global t0
        T = 1/self.scroll_speed
        t_max = t0 + T
        n = 5/self.scroll_speed
        A = 5
        X0 = 6
        dt = (now - t0) * 1e-9
        time.sleep(1/self.scroll_speed)
        y = self.sroll_text1.y - 1
        if y < 0:
            y = DISPLAY.height
        self.sroll_text1.y = y
        self.sroll_text2.y = -(DISPLAY.height - self.sroll_text1.y)
        x = round(X0 + sin(dt / n) * A)
        self.sroll_text2.x = self.sroll_text1.x = x
        while True:
            now = time.monotonic_ns()
            if now > t_max:
                break
            time.sleep((t_max - now) * 1e-9)
        t_max += T
        if append_flag == 0:
            append_flag = 1
            GROUP.append(self.sroll_text1)
            GROUP.append(self.sroll_text2)
            DISPLAY.root_group = GROUP
     
    # @brief: Display text horizontally from left to right
    # @param: self
    # @retval: None
    def text_left_to_right_horizontal(self):
        global append_flag
        self.sroll_text1.y = DISPLAY.height // 2
        self.sroll_text2.y = DISPLAY.height // 2
        x = self.sroll_text1.x + 1
        time.sleep(1/self.scroll_speed)
        if x > DISPLAY.width:
            x = 0
        self.sroll_text1.x = x
        self.sroll_text2.x = -(DISPLAY.width - self.sroll_text1.x)
        if append_flag == 0:
            append_flag = 1
            GROUP.append(self.sroll_text1)
            GROUP.append(self.sroll_text2)
            DISPLAY.root_group = GROUP
        
    # @brief: Display text horizontally from right to left
    # @param: self
    # @retval: None
    def text_right_to_left_horizontal(self):
        global append_flag
        self.sroll_text1.y = DISPLAY.height // 2
        self.sroll_text2.y = DISPLAY.height // 2
        x = self.sroll_text1.x - 1
        time.sleep(1/self.scroll_speed)
        if x < 0:
            x = DISPLAY.width
        self.sroll_text1.x = x
        self.sroll_text2.x = -(DISPLAY.width - self.sroll_text1.x)
        if append_flag == 0:
            append_flag = 1
            GROUP.append(self.sroll_text1)
            GROUP.append(self.sroll_text2)
            DISPLAY.root_group = GROUP

    # @brief: Display text vertically from top to bottom
    # @param: self
    # @retval: None
    def text_up_to_down_vertical(self):
        global append_flag
        self.sroll_text1.x = 0
        self.sroll_text2.x = 0
        y = self.sroll_text1.y + 1
        time.sleep(1/self.scroll_speed)
        if y > DISPLAY.height:
            y = 0
        self.sroll_text1.y = y
        self.sroll_text2.y = -(DISPLAY.height - self.sroll_text1.y)
        if append_flag == 0:
            append_flag = 1
            GROUP.append(self.sroll_text1)
            GROUP.append(self.sroll_text2)
            DISPLAY.root_group = GROUP
        
    # @brief: Display text vertically from bottom to top
    # @param: self
    # @retval: None
    def text_down_to_up_vertical(self):
        global append_flag
        self.sroll_text1.x = 0
        self.sroll_text2.x = 0
        y = self.sroll_text1.y - 1
        time.sleep(1/self.scroll_speed)
        if y < 0:
            y = DISPLAY.height
        self.sroll_text1.y = y
        self.sroll_text2.y = -(DISPLAY.height - self.sroll_text1.y)
        if append_flag == 0:
            append_flag = 1
            GROUP.append(self.sroll_text1)
            GROUP.append(self.sroll_text2)
            DISPLAY.root_group = GROUP

    # @brief: Display text with left-right rebound effect
    # @param: self
    # @retval: None
    def text_rebound_left_and_right(self):
        global append_flag
        self.sroll_text1.y = DISPLAY.height // 2
        time.sleep(1/self.scroll_speed) 
        if self.rebound_flag == 0:
            x = self.sroll_text1.x + 1
            if x > DISPLAY.width - self.sroll_text1.bounding_box[2]:
                self.rebound_flag = 1
        else:
            x = self.sroll_text1.x - 1
            if x < 0:
                self.rebound_flag = 0
        self.sroll_text1.x = x
        if append_flag == 0:
            append_flag = 1
            GROUP.append(self.sroll_text1)
            DISPLAY.root_group = GROUP

    # @brief: Display text with up-down rebound effect
    # @param: self
    # @retval: None
    def text_rebound_up_and_down(self):
        global append_flag
        time.sleep(1/self.scroll_speed)
        if self.rebound_flag == 0:
            y = self.sroll_text1.y + 1
            if y > DISPLAY.height - 8:
                self.rebound_flag = 1
        else:
            y = self.sroll_text1.y - 1
            if y < 3:
                self.rebound_flag = 0
        self.sroll_text1.y = y
        if append_flag == 0:
            append_flag = 1
            GROUP.append(self.sroll_text1)
            DISPLAY.root_group = GROUP
            
    # @brief: Select display mode
    # @param: mode number
    # @retval: None
    def test(self, mode):
        if mode == 1:
            self.static_image()
        elif mode == 2:
            self.image_left_to_right_horizontal()
        elif mode == 3:
            self.image_right_to_left_horizontal()
        elif mode == 4:
            self.image_up_to_down_vertical()
        elif mode == 5:
            self.image_down_to_up_vertical()
        elif mode == 6:
            self.static_text()
        elif mode == 7:
            self.text_sin_left_to_right()
        elif mode == 8:
            self.text_sin_right_to_left()
        elif mode == 9:
            self.text_sin_up_to_down()
        elif mode == 10:
            self.text_sin_down_to_up()
        elif mode == 11:
            self.text_left_to_right_horizontal()
        elif mode == 12:
            self.text_right_to_left_horizontal()
        elif mode == 13:
            self.text_up_to_down_vertical()
        elif mode == 14:
            self.text_down_to_up_vertical()
        elif mode == 15:
            self.text_rebound_left_and_right()
        elif mode == 16:
            self.text_rebound_up_and_down()

# Main program
if __name__ == '__main__':
    print("Initializing RGB matrix...")
    print(f"Display size: {width_value}x{height_value}")
    print(f"Bit depth: {bit_depth_value} bits")
    print("Using PIO hardware acceleration mode")
    
    # Create RGB API instance
    RGB = RGB_Api()
    GROUP = displayio.Group()
    
    print("Starting display mode demonstration...")
    
    try:
        print("Starting static image display...")
        # Remove redundant global declaration, append_flag is already defined in global scope
        append_flag = 0
        # Only call static image display mode
        RGB.test(1)
        while True:
            pass  # Keep program running
    except KeyboardInterrupt:
        print("Program stopped")
    finally:
        # Clean up resources
        displayio.release_displays()
        print("Resources released")